import { createSlice } from "@reduxjs/toolkit";


 const hospitalSlice=createSlice({
    name:""
 })